# XXX-XXX

[![Wallaby.js](https://img.shields.io/badge/wallaby.js-powered-blue.svg?style=flat&logo=github)](https://wallabyjs.com/oss/)

## inspired
* https://github.com/fpapado/eleventy-with-vite
* https://github.com/stefanjudis/tiny-helpers
* https://www.trysmudford.com/blog/encapsulated-11ty-components/

# prequisite
* Node 22.14.0 (used)


* Logos: https://github.com/PKief/vscode-material-icon-theme/tree/main/icons


# Documentation
* [docs](docs/index.md) - project documentation
* [PWA and offline documents](docs/pwa.md) - setup, caching and installation

* [Preparedness tools and tracking mock](docs/preparedness.md) - tabs, checklist, location and backend contract

* [JSON pager and cache controls](docs/pager.md) - messages, offline updates and completion theme
